from rdflib import Graph,RDF,RDFS,URIRef
import json,pathlib,re,shutil
root=pathlib.Path(__file__).resolve().parents[1]; base=root/'data/ttl'
def local(u): return re.split('[#/]','%s'%u)[-1]
def label(g,u):
 v=next(iter(g.objects(u,RDFS.label)),None);return str(v) if v is not None else local(u)
def ob(g,s,p):return [o for pp,o in g.predicate_objects(s) if local(pp)==p]
def val(g,s,p):return [str(v) for v in ob(g,s,p)]
def instances(g,typ):return sorted(set(s for s,o in g.subject_objects(RDF.type) if local(o)==typ),key=str)
subjects=[]; validation=[]
for f in sorted(base.glob('*_교육과정.ttl')):
 g=Graph();g.parse(f,format='turtle'); sub=instances(g,'Subject'); sub=next((s for s in sub if ob(g,s,'hasArea')),sub[0] if sub else None)
 if not sub:continue
 areas=[]; mapped=set()
 for a in ob(g,sub,'hasArea'):
  standards=[]
  for st in ob(g,a,'hasAchievementStandard'):
   mapped.add(str(st)); standards.append({'id':str(st),'code':(val(g,st,'standardCode') or [label(g,st)])[0], 'text':(val(g,st,'standardText') or val(g,st,'description') or [''])[0],'gradeBand':val(g,st,'gradeBand')})
  ideas=[{'id':str(v),'label':label(g,v),'description':' '.join(val(g,v,'description'))} for v in ob(g,a,'hasCoreIdea')]
  elems=[]
  for e in ob(g,a,'hasContentElement'):
   typ=next((local(t) for t in g.objects(e,RDF.type) if local(t) in ('KnowledgeUnderstanding','ProcessSkill','ValueAttitude')),'ContentElement')
   elems.append({'id':str(e),'label':label(g,e),'type':typ,'gradeBand':val(g,e,'gradeBand'),'description':' '.join(val(g,e,'description'))})
  areas.append({'id':str(a),'label':label(g,a),'ideas':ideas,'elements':elems,'standards':standards})
 unmapped=[{'id':str(st),'code':(val(g,st,'standardCode') or [label(g,st)])[0], 'text':(val(g,st,'standardText') or val(g,st,'description') or [''])[0], 'gradeBand':val(g,st,'gradeBand')} for st in instances(g,'AchievementStandard') if str(st) not in mapped]
 subjects.append({'id':local(sub),'label':label(g,sub),'source':f.name,'areas':areas,'unmappedStandards':unmapped})
 validation.append({'subject':label(g,sub),'areas':len(areas),'standards':sum(len(a['standards']) for a in areas)+len(unmapped),'unmappedStandards':len(unmapped),'elements':sum(len(a['elements']) for a in areas),'ideas':sum(len(a['ideas']) for a in areas),'triples':len(g)})
g=Graph();g.parse(base/'readstrategy.ttl',format='turtle');functions=[]
for s in instances(g,'ReadingFunction'):
 functions.append({'id':str(s),'label':label(g,s),'verbs':[label(g,v) for v in ob(g,s,'hasVerb')], 'strategies':[{'id':str(v),'label':label(g,v)} for v in ob(g,s,'hasStrategy')]})
g=Graph();g.parse(base/'text.ttl',format='turtle'); textcats=[]
for s in instances(g,'TextClassificationCategory'):
 textcats.append({'id':str(s),'label':label(g,s),'options':[{'id':str(v),'label':label(g,v)} for v in set(g.subjects(None,s)) if ob(g,v,'hasCategory') and s in ob(g,v,'hasCategory')]})
# fallback extract labels with text classification type if alternate ontology
textOptions=[{'id':str(s),'label':label(g,s),'type':local(next(iter(g.objects(s,RDF.type)),''))} for s in set(g.subjects(RDF.type,None)) if any('Text' in local(t) for t in g.objects(s,RDF.type)) and not any(local(t) in ('Class','ObjectProperty','DatatypeProperty') for t in g.objects(s,RDF.type))]
g=Graph();g.parse(base/'가네.ttl',format='turtle');events=[]
for s in instances(g,'InstructionalEvent'):
 seq=val(g,s,'sequenceNumber');
 if not seq:continue
 events.append({'id':str(s),'seq':int(seq[0]),'label':label(g,s),'example':' '.join(val(g,s,'exampleDescription'))})
data={'subjects':subjects,'functions':functions,'textCategories':textcats,'textOptions':textOptions,'events':sorted(events,key=lambda x:x['seq']),'validation':validation,'notice':'교육과정 TTL은 자동 추출된 1차 구조화본입니다. 표 병합·수식·학년군 및 영역 미확정 자료는 HWP 원문 대조가 필요합니다. 추천된 독서전략과 가네 사태 배치는 앱의 제안이며 공식 교육과정 관계가 아닙니다.'}
(root/'data/compiled.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print('subjects',len(subjects),'standards',sum(v['standards'] for v in validation),'functions',len(functions),'events',len(events));print(validation)
